/**
 * Employee Attendance Manager - WORKING VERSION
 * No strict mode errors, proper event handling
 */
(function ($) {

    // Global state
    var stream = null;
    var actionType = 'check_in';
    var employeeCalendar = null;
    var adminCalendar = null;
    var lastCaptureTime = 0;
    var CAPTURE_DEBOUNCE = 600;
    var originalModalBody = ''; // Store original form HTML

    // Force hide modal
    function hideModal() {
        console.log('Hiding modal');
        stopCamera();
        $('#eam-modal, #eam-modal-backdrop')
            .removeClass('is-open')
            .hide()
            .css({
                'display': 'none',
                'visibility': 'hidden',
                'opacity': '0'
            });
    }

    // Check if already checked in/out today
    function checkTodayStatus(callback) {
        $.post(EAM.ajax_url, {
            action: 'eam_today_status',
            nonce: EAM.nonce
        }).done(function (res) {
            if (res.success) {
                callback(res.data);
            } else {
                callback({});
            }
        }).fail(function () {
            callback({});
        });
    }

    // Show modal for check-in/out with status check
    function showModal(type) {
        console.log('Attempting to show modal:', type);

        // Check today's status first
        checkTodayStatus(function (status) {
            if (type === 'check_in' && status.check_in) {
                // Strictly limit check-ins to once per day - EXACT MESSAGE REQUESTED
                alert('Already Checked for the day');
                return;
            }

            if (type === 'check_out' && !status.check_in) {
                // Can't check out without checking in first
                alert('⚠ Check-In Required\n\nPlease check in first before checking out.');
                return;
            }

            // Note: Multiple check-outs are allowed as per user request, so we remove the already-checked-out check.


            // All checks passed, show modal
            actionType = type;

            // RESTORE original form HTML first
            if (originalModalBody) {
                $('#eam-modal-body').html(originalModalBody);
            }

            // Clear form
            $('#eam-action-type').val(type);
            $('#eam-note').val('');
            $('#eam-photo-data').val('');
            $('#eam-photo-preview, #eam-video, #eam-modal-error, #eam-modal-success').hide();

            // Set title
            $('#eam-modal-title').text(type === 'check_in' ? 'Check-In' : 'Check-Out');

            // Show
            $('#eam-modal').addClass('is-open').css({ 'display': 'flex', 'visibility': 'visible', 'opacity': '1' }).show();
            $('#eam-modal-backdrop').addClass('is-open').css({ 'display': 'flex', 'visibility': 'visible', 'opacity': '1' }).show();
        });
    }

    // Camera functions
    function startCamera() {
        if (stream) {
            console.log('Camera already running');
            return;
        }

        console.log('Starting camera');
        navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } })
            .then(function (s) {
                stream = s;
                var video = document.getElementById('eam-video');
                video.srcObject = stream;
                video.play();
                $('#eam-video').show();
                $('#eam-photo-preview').hide();
                console.log('Camera started');
            })
            .catch(function (err) {
                console.error('Camera error:', err);
                alert('Camera not available');
            });
    }

    function stopCamera() {
        if (stream) {
            console.log('Stopping camera');
            stream.getTracks().forEach(function (t) { t.stop(); });
            stream = null;
            $('#eam-video').hide();
        }
    }

    function capturePhoto() {
        var now = Date.now();
        if (now - lastCaptureTime < CAPTURE_DEBOUNCE) {
            console.log('Capture debounced');
            return;
        }
        lastCaptureTime = now;

        if (!stream) {
            alert('Please start the camera first');
            return;
        }

        console.log('Capturing photo');
        var video = document.getElementById('eam-video');
        var canvas = document.getElementById('eam-canvas');

        if (!video || !canvas) {
            alert('Camera elements not found');
            return;
        }

        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        canvas.getContext('2d').drawImage(video, 0, 0);

        var data = canvas.toDataURL('image/png');
        $('#eam-photo-data').val(data);
        $('#eam-photo-preview').attr('src', data).show();
        $('#eam-video').hide();
        stopCamera();
        console.log('Photo captured');
    }

    // Submit
    function submitAttendance() {
        var note = $('#eam-note').val().trim();
        var photo = $('#eam-photo-data').val();

        $('#eam-modal-error, #eam-modal-success').hide();

        if (!note) {
            $('#eam-modal-error').text('Note required').show();
            return;
        }
        if (!photo) {
            $('#eam-modal-error').text('Photo required').show();
            return;
        }

        $('#eam-submit-attendance').prop('disabled', true).text('Submitting...');

        $.post(EAM.ajax_url, {
            action: 'eam_submit_attendance',
            nonce: EAM.nonce,
            action_type: actionType,
            note: note,
            photo: photo
        }).done(function (res) {
            if (res.success) {
                $('#eam-modal-success').text('Success!').show();
                setTimeout(function () {
                    hideModal();
                    if (employeeCalendar) employeeCalendar.refetchEvents();
                    if (adminCalendar) adminCalendar.refetchEvents();
                }, 1500);
            } else {
                $('#eam-modal-error').text(res.data.message || 'Failed').show();
            }
        }).fail(function () {
            $('#eam-modal-error').text('Network error').show();
        }).always(function () {
            $('#eam-submit-attendance').prop('disabled', false).text('Submit');
        });
    }

    // Show day details popup
    function showDayDetails(date) {
        console.log('Loading day details:', date);

        $.post(EAM.ajax_url, {
            action: 'eam_get_day_details',
            nonce: EAM.nonce,
            date: date
        }).done(function (res) {
            if (res.success && res.data && res.data.exists) {
                var d = res.data;
                var html = '<div class="eam-day-details" style="padding:20px;">';
                html += '<h3 style="margin-top:0;">Attendance for ' + d.date + '</h3>';

                if (d.user_name) {
                    html += '<p><strong>Employee:</strong> ' + d.user_name + '</p>';
                }

                html += '<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin:20px 0;">';

                // Check-in column
                html += '<div>';
                html += '<h4 style="color:#10b981; margin-bottom:10px;">Check-In</h4>';
                if (d.check_in_photo) {
                    html += '<img src="' + d.check_in_photo + '" alt="Check-in" style="max-width:100%; border-radius:8px; margin-bottom:10px; box-shadow:0 2px 8px rgba(0,0,0,0.1);">';
                }
                html += '<p><strong>Time:</strong> ' + (d.check_in || 'N/A') + '</p>';
                html += '<p><strong>Note:</strong> ' + (d.check_in_note || 'N/A') + '</p>';
                html += '</div>';

                // Check-out column
                html += '<div>';
                html += '<h4 style="color:#ef4444; margin-bottom:10px;">Check-Out</h4>';
                if (d.check_out_photo) {
                    html += '<img src="' + d.check_out_photo + '" alt="Check-out" style="max-width:100%; border-radius:8px; margin-bottom:10px; box-shadow:0 2px 8px rgba(0,0,0,0.1);">';
                }
                html += '<p><strong>Time:</strong> ' + (d.check_out || 'N/A') + '</p>';
                html += '<p><strong>Note:</strong> ' + (d.check_out_note || 'N/A') + '</p>';
                html += '</div>';

                html += '</div>';

                if (d.total_hours) {
                    html += '<div style="background:#eff6ff; padding:15px; border-radius:8px; text-align:center;">';
                    html += '<p style="font-size:18px; font-weight:bold; margin:0; color:#2563eb;">Total Duration: ' + d.total_hours + '</p>';
                    html += '</div>';
                }

                html += '</div>';

                // Show in modal
                $('#eam-modal-title').text('Attendance Details');
                $('#eam-modal-body').html(html);
                $('#eam-modal').addClass('is-open').css({ 'display': 'flex', 'visibility': 'visible', 'opacity': '1' }).show();
                $('#eam-modal-backdrop').addClass('is-open').css({ 'display': 'flex', 'visibility': 'visible', 'opacity': '1' }).show();
            } else {
                alert('No attendance record found for this date');
            }
        }).fail(function () {
            alert('Failed to load details');
        });
    }

    // Admin table
    function loadAdminTable(date) {
        var employeeId = $('#eam-filter-employee').val() || '';
        var from = $('#eam-filter-from').val() || '';
        var to = $('#eam-filter-to').val() || '';

        $.post(EAM.ajax_url, {
            action: 'eam_admin_table',
            nonce: EAM.nonce,
            employee_id: employeeId,
            from: from,
            to: to,
            date: date || ''
        }).done(function (res) {
            if (res.success) {
                renderAdminTable(res.data);
            }
        });
    }

    function renderAdminTable(data) {
        var tbody = $('#eam-admin-table tbody');
        tbody.empty();

        if (!data || data.length === 0) {
            tbody.append('<tr><td colspan="9">No records</td></tr>');
            return;
        }

        data.forEach(function (row) {
            var inPhoto = row.check_in_photo ? '<a href="' + row.check_in_photo + '" target="_blank">View</a>' : '-';
            var outPhoto = row.check_out_photo ? '<a href="' + row.check_out_photo + '" target="_blank">View</a>' : '-';

            tbody.append(
                '<tr>' +
                '<td>' + row.date + '</td>' +
                '<td>' + row.employee + '</td>' +
                '<td>' + (row.check_in || '-') + '</td>' +
                '<td>' + (row.check_out || '-') + '</td>' +
                '<td>' + (row.total_hours || '-') + '</td>' +
                '<td>' + inPhoto + '</td>' +
                '<td>' + outPhoto + '</td>' +
                '<td>' + (row.check_in_note || '-') + '</td>' +
                '<td>' + (row.check_out_note || '-') + '</td>' +
                '</tr>'
            );
        });
    }

    // Calendars
    function initCalendars() {
        // Employee calendar
        if ($('#eam-employee-calendar').length && !employeeCalendar) {
            console.log('Init employee calendar');
            employeeCalendar = new FullCalendar.Calendar(document.getElementById('eam-employee-calendar'), {
                initialView: 'dayGridMonth',
                height: 'auto',
                headerToolbar: { left: 'prev,next today', center: 'title', right: '' },
                events: function (info, success) {
                    $.get(EAM.ajax_url, {
                        action: 'eam_get_events',
                        nonce: EAM.nonce,
                        start: info.startStr,
                        end: info.endStr
                    }).done(function (r) { success(r.data || []); });
                },
                dateClick: function (info) {
                    console.log('Date clicked:', info.dateStr);
                    showDayDetails(info.dateStr);
                }
            });
            employeeCalendar.render();
        }

        // Admin calendar
        if ($('#eam-admin-calendar').length && !adminCalendar) {
            console.log('Init admin calendar');
            adminCalendar = new FullCalendar.Calendar(document.getElementById('eam-admin-calendar'), {
                initialView: 'dayGridMonth',
                height: 'auto',
                headerToolbar: { left: 'prev,next today', center: 'title', right: '' },
                events: function (info, success) {
                    $.get(EAM.ajax_url, {
                        action: 'eam_get_events',
                        nonce: EAM.nonce,
                        start: info.startStr,
                        end: info.endStr,
                        user_id: $('#eam-filter-employee').val() || ''
                    }).done(function (r) { success(r.data || []); });
                },
                dateClick: function (info) {
                    loadAdminTable(info.dateStr);
                }
            });
            adminCalendar.render();
        }
    }

    // Initialize
    function init() {
        console.log('EAM Init');
        hideModal();

        if ($('#eam-employee-calendar').length === 0) {
            return;
        }

        function waitFC(cb) {
            if (typeof FullCalendar !== 'undefined') {
                cb();
            } else {
                setTimeout(function () { waitFC(cb); }, 100);
            }
        }

        waitFC(function () {
            // Store original modal body HTML
            originalModalBody = $('#eam-modal-body').html();
            console.log('Original modal body stored');

            initCalendars();

            $(document).on('click', '#eam-open-checkin', function (e) {
                e.preventDefault();
                e.stopPropagation();
                showModal('check_in');
            });

            $(document).on('click', '#eam-open-checkout', function (e) {
                e.preventDefault();
                e.stopPropagation();
                showModal('check_out');
            });

            $(document).on('click', '#eam-capture-photo', function (e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('Capture button clicked, stream:', !!stream);
                if (!stream) {
                    startCamera();
                } else {
                    capturePhoto();
                }
            });

            $(document).on('click', '#eam-submit-attendance', function (e) {
                e.preventDefault();
                e.stopPropagation();
                submitAttendance();
            });

            $(document).on('click', '#eam-modal-close, #eam-cancel-modal', function (e) {
                e.preventDefault();
                e.stopPropagation();
                hideModal();
            });

            $(document).on('click', '#eam-modal-backdrop', function (e) {
                e.preventDefault();
                e.stopPropagation();
                hideModal();
            });

            $(document).on('click', '#eam-filter-apply', function () {
                if (adminCalendar) adminCalendar.refetchEvents();
                loadAdminTable();
            });

            console.log('All event handlers registered with delegation');
        });
    }

    $(document).ready(init);
    $(window).on('load pageshow', hideModal);

})(jQuery);
