=== Employee Attendance Manager ===
Contributors: hubator
Tags: attendance, employee, hr, timesheet, shift, clockin
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Complete attendance tracking with clock-in/out and reports.

== Description ==
Employee attendance manager with clock-in/out, shift scheduling, CSV exports.

== Installation ==
1. Upload to `/wp-content/plugins/`
2. Activate plugin
3. Configure at Attendance > Settings

== Changelog ==
= 1.0.0 =
* Initial release
